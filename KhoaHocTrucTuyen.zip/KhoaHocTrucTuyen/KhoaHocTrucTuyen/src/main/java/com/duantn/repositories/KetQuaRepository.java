package com.duantn.repositories;

import com.duantn.entities.KetQua;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface KetQuaRepository extends JpaRepository<KetQua, Integer> {

    @Query("SELECT kq FROM KetQua kq " +
           "LEFT JOIN FETCH kq.ketQuaChiTiet kct " +
           "LEFT JOIN FETCH kct.cauHoi ch " +
           "LEFT JOIN FETCH ch.dapAns " +
           "WHERE kq.ketquaId = :ketquaId")
    Optional<KetQua> findByIdWithDetails(@Param("ketquaId") Integer ketquaId);

    // Lấy tất cả kết quả và sắp xếp theo ngày hoàn thành
    List<KetQua> findAllByOrderByThoiGianKetThucDesc();
} 