package com.duantn.configs;

import jakarta.annotation.PostConstruct;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.duantn.entities.*;
import com.duantn.enums.HinhThucThanhToan;
import com.duantn.enums.TrangThaiGiaoDich;
import com.duantn.repositories.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Component
@RequiredArgsConstructor
public class DataInitializer {

    private final TaiKhoanRepository accountRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final KhoaHocRepository khoaHocRepository;
    private final GiaoDichKhoaHocRepository giaoDichKhoaHocRepository;
    private final GiaoDichKhoaHocChiTietRepository giaoDichKhoaHocChiTietRepository;
    private final DanhMucRepository danhMucRepository;
    private final GiangVienRepository giangVienRepository;

    private void ensureRoleExists(String roleName) {
        roleRepository.findByName(roleName).orElseGet(() -> {
            Role role = Role.builder().name(roleName).build();
            return roleRepository.save(role);
        });
    }

    @PostConstruct
    @Transactional
    public void init() {
        String superAdminEmail = "globaledu237@gmail.com";

        // Tạo các vai trò cần thiết
        ensureRoleExists("ROLE_ADMIN");
        ensureRoleExists("ROLE_NHANVIEN");
        ensureRoleExists("ROLE_GIANGVIEN");
        ensureRoleExists("ROLE_HOCVIEN");

        if (accountRepository.existsByEmail(superAdminEmail)) {
            // Nếu đã có Super Admin, không làm gì thêm
            return;
        }

        Role adminRole = roleRepository.findByName("ROLE_ADMIN").orElseThrow();

        TaiKhoan superAdminUser = TaiKhoan.builder()
                .name("Super Admin")
                .email(superAdminEmail)
                .password(passwordEncoder.encode("superpassword"))
                .role(adminRole)
                .build();

        accountRepository.saveAndFlush(superAdminUser);

        System.out.println("✅ Super Admin đã được khởi tạo thành công!");
    }

    // private void createSampleGiaoDichData() { ... } // Tạm thời vô hiệu hóa hoàn toàn
}