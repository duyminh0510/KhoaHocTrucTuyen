package com.duantn.controllers.controllerHocVien;

import com.duantn.entities.KetQua;
import com.duantn.services.KetQuaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/hoc-vien/ket-qua")
public class KetQuaController {

    @Autowired
    private KetQuaService ketQuaService;

    // Hiển thị danh sách kết quả
    @GetMapping
    public String listKetQua(Model model) {
        List<KetQua> danhSachKetQua = ketQuaService.getDanhSachTatCaKetQua();
        model.addAttribute("danhSachKetQua", danhSachKetQua);
        return "views/gdienHocVien/danh-sach-ket-qua";
    }

    // Hiển thị chi tiết một kết quả
    @GetMapping("/{id}")
    public String viewKetQua(@PathVariable("id") Integer id, Model model) {
        Optional<KetQua> ketQuaOpt = ketQuaService.getKetQuaChiTiet(id);

        if (ketQuaOpt.isPresent()) {
            model.addAttribute("ketQua", ketQuaOpt.get());
            return "views/gdienHocVien/ket-qua-trac-nghiem";
        } else {
            // Tạm thời chuyển hướng về trang chủ nếu không tìm thấy
            // Bạn có thể tạo một trang lỗi chuyên dụng nếu muốn
            return "redirect:/hoc-vien/home"; 
        }
    }
} 