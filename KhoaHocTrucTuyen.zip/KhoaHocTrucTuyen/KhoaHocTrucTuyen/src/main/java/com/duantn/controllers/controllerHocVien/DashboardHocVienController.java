package com.duantn.controllers.controllerHocVien;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/hoc-vien")
public class DashboardHocVienController {
    @RequestMapping("")
    public String dashboard() {
        return "views/gdienHocVien/home";
    }
}
