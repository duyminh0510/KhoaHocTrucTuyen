package com.duantn.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "CartItem")
public class CartItem implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "dongia", precision = 12, scale = 2, nullable = false)
    private BigDecimal dongia;

    @CreationTimestamp
    @Column(name = "NgayThem", nullable = false)
    private LocalDateTime ngayThem;

    @ManyToOne
    @JoinColumn(name = "cartId", nullable = false)
    private Cart carts;

    @ManyToOne
    @JoinColumn(name = "courseId", nullable = false)
    private Course courses;
}
