package com.duantn.entities;

import java.io.Serializable;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "danh_gia")
public class DanhGia implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "danhgia_id")
    private Long danhGiaId;

    @Column(name = "diem_danh_gia")
    private Integer diemDanhGia;

    @Column(name = "ngay_danh_gia")
    private LocalDateTime ngayDanhGia;

    @Column(name = "noi_dung", columnDefinition = "TEXT")
    private String noiDung;

    @Column(name = "account_id")
    private Long accountId;

    @Column(name = "course_id")
    private Long courseId;

    // Constructors
    public DanhGia() {}

    public DanhGia(Integer diemDanhGia, String noiDung, Long accountId, Long courseId) {
        this.diemDanhGia = diemDanhGia;
        this.ngayDanhGia = LocalDateTime.now();
        this.noiDung = noiDung;
        this.accountId = accountId;
        this.courseId = courseId;
    }

    // Getters and Setters
    public Long getDanhGiaId() {
        return danhGiaId;
    }

    public void setDanhGiaId(Long danhGiaId) {
        this.danhGiaId = danhGiaId;
    }

    public Integer getDiemDanhGia() {
        return diemDanhGia;
    }

    public void setDiemDanhGia(Integer diemDanhGia) {
        this.diemDanhGia = diemDanhGia;
    }

    public LocalDateTime getNgayDanhGia() {
        return ngayDanhGia;
    }

    public void setNgayDanhGia(LocalDateTime ngayDanhGia) {
        this.ngayDanhGia = ngayDanhGia;
    }

    public String getNoiDung() {
        return noiDung;
    }

    public void setNoiDung(String noiDung) {
        this.noiDung = noiDung;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public Long getCourseId() {
        return courseId;
    }

    public void setCourseId(Long courseId) {
        this.courseId = courseId;
    }

    @Override
    public String toString() {
        return "DanhGia{" +
                "danhGiaId=" + danhGiaId +
                ", diemDanhGia=" + diemDanhGia +
                ", ngayDanhGia=" + ngayDanhGia +
                ", noiDung='" + noiDung + '\'' +
                ", accountId=" + accountId +
                ", courseId=" + courseId +
                '}';
    }
}
