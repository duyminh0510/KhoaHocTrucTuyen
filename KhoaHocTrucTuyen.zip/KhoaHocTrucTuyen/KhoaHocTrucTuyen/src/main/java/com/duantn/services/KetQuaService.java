package com.duantn.services;

import com.duantn.entities.KetQua;
import com.duantn.repositories.KetQuaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class KetQuaService {

    @Autowired
    private KetQuaRepository ketQuaRepository;

    @Transactional(readOnly = true)
    public Optional<KetQua> getKetQuaChiTiet(Integer ketquaId) {
        return ketQuaRepository.findByIdWithDetails(ketquaId);
    }

    @Transactional(readOnly = true)
    public List<KetQua> getDanhSachTatCaKetQua() {
        return ketQuaRepository.findAllByOrderByThoiGianKetThucDesc();
    }
} 